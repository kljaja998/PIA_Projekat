export interface Setting{
    name: String,
    value: Number
}