export enum RoutePaths{
    Login = "login",
    Admin = "admin",
    Agent = "agent",
    Error = "error",
    Register = "register",
    Profile = "profile",
    default = "",
    wildcard = "**",
    AddProperty = "add-property",
    Property = "property"
}