export enum PropertyCategories{
    House = "House",
    Appartment = "Appartment"
}