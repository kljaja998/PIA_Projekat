export enum Furnished{
    Unfurnished = "Unfurnished",
    Furnished = "Furnished"
}