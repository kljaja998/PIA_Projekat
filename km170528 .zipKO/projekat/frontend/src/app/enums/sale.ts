export enum Sale{
    Sale = "Sale",
    Rent = "Rent"
}