export enum ApiPaths {
    Auth = "/auth",
    User = "/user",
    Messaging = "/messaging",
    Settings = "/settings",
    RealEstates = "/real-estate",
    Assets = "/assets",
}