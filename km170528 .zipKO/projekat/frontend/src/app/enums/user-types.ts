export enum UserType{
    Admin = "Admin",
    Agent = "Agent",
    User = "User"
}